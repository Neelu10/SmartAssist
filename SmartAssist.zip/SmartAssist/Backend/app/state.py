state = {"conversation_history": [], "is_escalation": False}
